package in.sp.main.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.sp.main.Services.UserServices;
import in.sp.main.entities.User;

@RestController
public class MyController {
	
	@Autowired
	private UserServices userServices;
	@PostMapping("/user")
	public User addUserDetails(@RequestBody User user)
	{
		return userServices.createUser(user);
	}
	
	@GetMapping("/user")
	public List<User> getAllUserDetails() {
		return userServices.getAllUser();
	}
	
	@GetMapping("/user/{id}")
	public ResponseEntity<User> getUserDetails(@PathVariable int id) {
		User user=userServices.getUserDetails(id).orElse(null);
		if(user!=null) {
			return ResponseEntity.ok().body(user);
		}else {
			return ResponseEntity.notFound().build();
		}
	}
    @PutMapping("/user/{id}")
    public ResponseEntity<User>updateUser(@PathVariable int id , @RequestBody User user){
    	User newuser=userServices.updateUser(id, user);
    	if(newuser!=null) {
    		return ResponseEntity.ok(newuser);
    	}else {
    		return ResponseEntity.notFound().build();
    	}
    	
    }
    
   @DeleteMapping("/user/{id}")
   public ResponseEntity<String> deleteUser(@PathVariable int id){
	   userServices.deleteUser(id);
	   return ResponseEntity.ok("User delete Succesfully");
   }

	
}
