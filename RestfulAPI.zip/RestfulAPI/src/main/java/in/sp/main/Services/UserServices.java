package in.sp.main.Services;

import java.util.List;
import java.util.Optional;

import in.sp.main.entities.User;

public interface UserServices 
{
	public User createUser(User user);
	
	public List<User> getAllUser();
	
	public Optional<User> getUserDetails(int id);
	
	public User updateUser(int id,User updateUser);
	
	public void deleteUser(int id);
}
