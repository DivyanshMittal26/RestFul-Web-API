package in.sp.main.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sp.main.entities.User;
import in.sp.main.repositories.UserRepository;

@Service
public class UserServiceImp implements UserServices
{
	@Autowired
	private UserRepository userRepository;
	@Override
	public User createUser(User user) {
		return userRepository.save(user);
	}
	@Override
	public List<User> getAllUser() {
		
		return userRepository.findAll();
	}
	@Override
	public Optional<User> getUserDetails(int id) {
		
		return userRepository.findById(id);
	}

	@Override
	public User updateUser(int id, User newuser) {
		User user=userRepository.findById(id).orElse(null);
		if(user!=null) {
			return userRepository.save(newuser);
		}else {
		//return null;
		throw new RuntimeException("user Not Found");
		}
	}
	@Override
	public void deleteUser(int id) {
		userRepository.deleteById(id);
		
	}
		}
